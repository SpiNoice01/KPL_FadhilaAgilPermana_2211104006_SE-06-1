﻿using System;
using System.IO;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace TPModul7
{
    public static class ProgramBacaJson
    {
        public static void Main()
        {
            DataMahasiswa2211104006.ReadJSON();
            DataKelas.ReadJSON();
            GlosarryItem2211104006.ReadJSON();
        }
    }

    // Kelas untuk menyimpan nama mahasiswa
    public class Nama
    {
        public required string Depan { get; set; }
        public required string Belakang { get; set; }
    }

    // Kelas untuk menyimpan data mahasiswa
    public class DataMahasiswa2211104006
    {
        public required Nama Nama { get; set; }
        public long NIM { get; set; }
        public required string Fakultas { get; set; }

        public static void ReadJSON()
        {
            string filePath = "jurnal7_1_2211104006.json"; // File mahasiswa

            if (File.Exists(filePath))
            {
                string jsonContent = File.ReadAllText(filePath);
                var mahasiswa = JsonConvert.DeserializeObject<DataMahasiswa2211104006>(jsonContent);

                if (mahasiswa?.Nama != null)
                {
                    Console.WriteLine("=== Data Mahasiswa ===");
                    Console.WriteLine($"Nama: {mahasiswa.Nama.Depan} {mahasiswa.Nama.Belakang}");
                    Console.WriteLine($"NIM: {mahasiswa.NIM}");
                    Console.WriteLine($"Fakultas: {mahasiswa.Fakultas}");
                    Console.WriteLine();
                }
                else
                {
                    Console.WriteLine("Data mahasiswa tidak valid!");
                }
            }
            else
            {
                Console.WriteLine("File JSON mahasiswa tidak ditemukan!");
            }
        }
    }

    // Kelas untuk menyimpan informasi mata kuliah
    public class Course
    {
        public required string Code { get; set; }
        public required string Name { get; set; }
    }

    // Kelas untuk menyimpan daftar mata kuliah
    public class DataKelas
    {
        public required List<Course> Courses { get; set; }

        public static void ReadJSON()
        {
            string filePath = "jurnal7_2_2211104006.json"; // File mata kuliah

            if (File.Exists(filePath))
            {
                string jsonContent = File.ReadAllText(filePath);
                var dataKelas = JsonConvert.DeserializeObject<DataKelas>(jsonContent);

                if (dataKelas?.Courses != null)
                {
                    Console.WriteLine("=== Daftar Mata Kuliah ===");
                    foreach (var course in dataKelas.Courses)
                    {
                        Console.WriteLine($"Kode: {course.Code}, Nama: {course.Name}");
                                            }
                    Console.WriteLine();
                }
                else
                {
                    Console.WriteLine("Data mata kuliah tidak valid!");
                }
            }
            else
            {
                Console.WriteLine("File JSON mata kuliah tidak ditemukan!");
            }
        }
    }

    // Kelas untuk menyimpan informasi glosarium
    public class GlossDef
    {
        public required string Para { get; set; }
        public required List<string> GlossSeeAlso { get; set; }
    }

    public class GlossEntry
    {
        public required string ID { get; set; }
        public required string SortAs { get; set; }
        public required string GlossTerm { get; set; }
        public required string Acronym { get; set; }
        public required string Abbrev { get; set; }
        public required GlossDef GlossDef { get; set; }
        public required string GlossSee { get; set; }
    }

    public class GlossList
    {
        public required GlossEntry GlossEntry { get; set; }
    }

    public class GlossDiv
    {
        public required string Title { get; set; }
        public required GlossList GlossList { get; set; }
    }

    public class Glossary
    {
        public required string Title { get; set; }
        public required GlossDiv GlossDiv { get; set; }
    }

    // Kelas untuk menyimpan daftar glosarium
    public class GlosarryItem2211104006
    {
        public required Glossary Glossary { get; set; }

        public static void ReadJSON()
        {
            string filePath = "jurnal7_3_2211104006.json"; // File glosarium

            if (File.Exists(filePath))
            {
                string jsonContent = File.ReadAllText(filePath);
                var dataGlosarium = JsonConvert.DeserializeObject<GlosarryItem2211104006>(jsonContent);

                if (dataGlosarium?.Glossary != null)
                {
                    
                    Console.WriteLine("=== Daftar Glosarium ===");
                    Console.WriteLine($"Title: {dataGlosarium.Glossary.Title}");
                    Console.WriteLine($"GlossDiv Title: {dataGlosarium.Glossary.GlossDiv.Title}");
                    var glossEntry = dataGlosarium.Glossary.GlossDiv.GlossList.GlossEntry;
                    Console.WriteLine($"ID: {glossEntry.ID}");
                    Console.WriteLine($"Term: {glossEntry.GlossTerm}");
                    Console.WriteLine($"Definition: {glossEntry.GlossDef.Para}");
                }
                else
                {
                    Console.WriteLine("Data glosarium tidak valid!");
                }
            }
            else
            {
                Console.WriteLine("File JSON glosarium tidak ditemukan!");
            }
        }
    }
}
