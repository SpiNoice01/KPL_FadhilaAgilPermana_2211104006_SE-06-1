﻿using System;
using System.Collections.Generic;

public class PusatDataSingleton
{
    private static PusatDataSingleton _instance;
    private List<string> DataTersimpan;

    // Konstruktor private
    private PusatDataSingleton()
    {
        DataTersimpan = new List<string>();
    }

    // Getter singleton
    public static PusatDataSingleton GetDataSingleton()
    {
        if (_instance == null)
        {
            _instance = new PusatDataSingleton();
        }
        return _instance;
    }

    public List<string> GetSemuaData()
    {
        return DataTersimpan;
    }

    public void PrintSemuaData()
    {
        foreach (var data in DataTersimpan)
        {
            Console.WriteLine(data);
        }
    }

    public void AddSebuahData(string input)
    {
        DataTersimpan.Add(input);
    }

    public void HapusSebuahData(int index)
    {
        if (index >= 0 && index < DataTersimpan.Count)
        {
            DataTersimpan.RemoveAt(index);
        }
        else
        {
            Console.WriteLine("Index tidak valid.");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // A & B
            var data1 = PusatDataSingleton.GetDataSingleton();
            var data2 = PusatDataSingleton.GetDataSingleton();

            // C - Tambah data
            data1.AddSebuahData("Anggota 1");
            data1.AddSebuahData("Anggota 2");
            data1.AddSebuahData("Asisten Praktikum: Kak Budi");

            // D - Print semua data dari data2
            Console.WriteLine("Data dari data2:");
            data2.PrintSemuaData();

            // E - Hapus asisten praktikum
            data2.HapusSebuahData(2); // index ke-2 = Asisten Praktikum

            // F - Print ulang data1
            Console.WriteLine("\nData dari data1 setelah penghapusan:");
            data1.PrintSemuaData();

            // G - Print jumlah data
            Console.WriteLine($"\nJumlah data di data1: {data1.GetSemuaData().Count}");
            Console.WriteLine($"Jumlah data di data2: {data2.GetSemuaData().Count}");
        }
    }

}
