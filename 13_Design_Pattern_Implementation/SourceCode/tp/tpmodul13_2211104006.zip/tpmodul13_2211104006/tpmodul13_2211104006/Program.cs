﻿using System;
using System.Collections.Generic;

// Subject
public interface ISubject
{
    void Attach(IObserver observer);
    void Detach(IObserver observer);
    void Notify();
}

public class WeatherStation : ISubject
{
    private List<IObserver> observers = new List<IObserver>();
    private int temperature;

    public void Attach(IObserver observer)
    {
        observers.Add(observer);
    }

    public void Detach(IObserver observer)
    {
        observers.Remove(observer);
    }

    public void Notify()
    {
        foreach (var observer in observers)
        {
            observer.Update(temperature);
        }
    }

    public void SetTemperature(int temp)
    {
        Console.WriteLine($"\n[WeatherStation] Suhu berubah menjadi {temp}°C");
        temperature = temp;
        Notify();
    }
}

// Observer
public interface IObserver
{
    void Update(int temperature);
}

public class PhoneDisplay : IObserver
{
    public void Update(int temperature)
    {
        Console.WriteLine($"[PhoneDisplay] Menampilkan suhu: {temperature}°C");
    }
}

public class WindowDisplay : IObserver
{
    public void Update(int temperature)
    {
        Console.WriteLine($"[WindowDisplay] Menampilkan suhu: {temperature}°C");
    }
}

// Main program
class Program
{
    static void Main(string[] args)
    {
        var weatherStation = new WeatherStation();

        var phoneDisplay = new PhoneDisplay();
        var windowDisplay = new WindowDisplay();

        weatherStation.Attach(phoneDisplay);
        weatherStation.Attach(windowDisplay);

        weatherStation.SetTemperature(25);
        weatherStation.SetTemperature(30);

        weatherStation.Detach(windowDisplay);

        weatherStation.SetTemperature(20);
    }
}
