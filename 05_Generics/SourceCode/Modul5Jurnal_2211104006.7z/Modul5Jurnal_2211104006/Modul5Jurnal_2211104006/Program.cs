﻿using System;
using System.Collections.Generic;

// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");

int nimAkhir = 6; // Ganti dengan digit terakhir NIM Anda
dynamic angka1, angka2, angka3;

if (nimAkhir == 1 || nimAkhir == 2)
{
    angka1 = 12f;
    angka2 = 34f;
    angka3 = 56f;
}
else if (nimAkhir == 3 || nimAkhir == 4 || nimAkhir == 5)
{
    angka1 = 12.0;
    angka2 = 34.0;
    angka3 = 56.0;
}
else if (nimAkhir == 6 || nimAkhir == 7 || nimAkhir == 8)
{
    angka1 = 12;
    angka2 = 34;
    angka3 = 56;
}
else
{
    angka1 = 12L;
    angka2 = 34L;
    angka3 = 56L;
}

Penjumlahan penjumlahan = new Penjumlahan();
var hasil = penjumlahan.JumlahTigaAngka(angka1, angka2, angka3);
Console.WriteLine($"Hasil penjumlahan: {hasil}");

SimpleDataBase<dynamic> dataBase = new SimpleDataBase<dynamic>();
dataBase.AddNewData(angka1);
dataBase.AddNewData(angka2);

public class Penjumlahan
{
    public T JumlahTigaAngka<T>(T angka1, T angka2, T angka3)
    {
        dynamic a = angka1;
        dynamic b = angka2;
        dynamic c = angka3;
        return a + b + c;
    }
}

public class SimpleDataBase<T>
{
    private List<T> storedData;
    private List<DateTime> inputDates;

    public SimpleDataBase()
    {
        storedData = new List<T>();
        inputDates = new List<DateTime>();
    }

    public void AddNewData(T data)
    {
        storedData.Add(data);
        inputDates.Add(DateTime.Now);
    }

    public void PrintAllData()
    {
        for (int i = 0; i < storedData.Count; i++)
        {
            Console.WriteLine($"Data {i + 1} berisi: {storedData[i]}, yang disimpan pada waktu UTC: {inputDates[i].ToUniversalTime()}");
        }
    }
}