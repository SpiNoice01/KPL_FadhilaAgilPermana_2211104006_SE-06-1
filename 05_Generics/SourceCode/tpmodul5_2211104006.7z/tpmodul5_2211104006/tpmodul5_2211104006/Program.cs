﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");

// Class HaloGeneric
public class HaloGeneric
{
    public void SapaUser<T>(T user)
    {
        Console.WriteLine($"Halo user {user}");
    }
}

// Class DataGeneric
public class DataGeneric<T>
{
    public T Data { get; private set; }

    public DataGeneric(T data)
    {
        Data = data;
    }

    public void PrintData()
    {
        Console.WriteLine($"Data yang tersimpan adalah: {Data}");
    }
}

// Main method
public partial class Program
{
    static void Main(string[] args)
    {

        var haloGeneric = new HaloGeneric();
        haloGeneric.SapaUser("Praktikan");

        var dataGeneric = new DataGeneric<string>("2211104006");
        dataGeneric.PrintData();
    }
}
