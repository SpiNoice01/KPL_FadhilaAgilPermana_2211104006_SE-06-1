﻿namespace TPModul3_2211104006
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.InputanBox = new System.Windows.Forms.TextBox();
            this.Butt = new System.Windows.Forms.Button();
            this.Output = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // InputanBox
            // 
            this.InputanBox.Location = new System.Drawing.Point(12, 12);
            this.InputanBox.Name = "InputanBox";
            this.InputanBox.Size = new System.Drawing.Size(260, 20);
            this.InputanBox.TabIndex = 0;
            // 
            // Butt
            // 
            this.Butt.Location = new System.Drawing.Point(12, 38);
            this.Butt.Name = "Butt";
            this.Butt.Size = new System.Drawing.Size(75, 23);
            this.Butt.TabIndex = 1;
            this.Butt.Text = "Sapa :D";
            this.Butt.UseVisualStyleBackColor = true;
            this.Butt.Click += new System.EventHandler(this.Butt_Click);
            // 
            // Output
            // 
            this.Output.AutoSize = true;
            this.Output.Location = new System.Drawing.Point(12, 64);
            this.Output.Name = "Output";
            this.Output.Size = new System.Drawing.Size(0, 13);
            this.Output.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.Output);
            this.Controls.Add(this.Butt);
            this.Controls.Add(this.InputanBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label Output;
        private System.Windows.Forms.Button Butt;
        private System.Windows.Forms.TextBox InputanBox;
    }
}

