using Microsoft.AspNetCore.Mvc;

namespace TP_modul9_2211104006.Controllers;

[ApiController]
[Route("[controller]")]
public class Mahasiswa
{
    public string Nama { get; set; }
    public string Nim { get; set; }
}

[ApiController]
[Route("api/[controller]")]
public class MahasiswaController : ControllerBase
{
    private static List<Mahasiswa> daftarMahasiswa = new List<Mahasiswa>
    {
        new Mahasiswa { Nama = "Nama Kamu", Nim = "NIM Kamu" },
        new Mahasiswa { Nama = "Nama Teman 1", Nim = "NIM Teman 1" },
        new Mahasiswa { Nama = "Nama Teman 2", Nim = "NIM Teman 2" }
    };

    [HttpGet]
    public IEnumerable<Mahasiswa> Get()
    {
        return daftarMahasiswa;
    }

    [HttpGet("{index}")]
    public ActionResult<Mahasiswa> GetByIndex(int index)
    {
        if (index < 0 || index >= daftarMahasiswa.Count)
            return NotFound();
        return daftarMahasiswa[index];
    }

    [HttpPost]
    public ActionResult Post([FromBody] Mahasiswa mhs)
    {
        daftarMahasiswa.Add(mhs);
        return Ok();
    }

    [HttpDelete("{index}")]
    public ActionResult Delete(int index)
    {
        if (index < 0 || index >= daftarMahasiswa.Count)
            return NotFound();
        daftarMahasiswa.RemoveAt(index);
        return Ok();
    }
}
