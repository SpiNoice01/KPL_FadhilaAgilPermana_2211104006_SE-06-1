﻿using System;


// TUGAS 3, Bagian A
//partial class Program
//{
//    static void Main(string[] args)
//    {
//        Console.WriteLine("Hello, World!");

//        // Meminta pengguna untuk memasukkan huruf
//        Console.Write("Masukkan huruf: ");
//        char inputChar = Console.ReadKey().KeyChar;
//        Console.WriteLine(); // Pindah ke baris baru setelah input

//        // Memeriksa dan menampilkan hasil
//        string result = CheckCharacter(inputChar);
//        Console.WriteLine($"Huruf {inputChar} merupakan huruf {result}");
//    }

//    static string CheckCharacter(char c)
//    {
//        char upperChar = Char.ToUpper(c);
//        if (upperChar == 'A' || upperChar == 'I' || upperChar == 'U' || upperChar == 'E' || upperChar == 'O')
//        {
//            return "vokal";
//        }
//        else
//        {
//            return "konsonan";
//        }
//    }
//}


// TUGAS 3, Bagian B
partial class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Hello, World!");

        // Membuat array dengan 5 bilangan genap dari angka 2
        int[] evenNumbers = { 2, 4, 6, 8, 10 };

        // Melakukan iterasi dan mencetak output dari tiap elemen
        for (int i = 0; i < evenNumbers.Length; i++)
        {
            Console.WriteLine($"Angka genap {i + 1} : {evenNumbers[i]}");
        }
    }
}
