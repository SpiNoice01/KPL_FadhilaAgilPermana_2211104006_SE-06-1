﻿using System;

// A Welcoming Nama
//namespace SelamatDatang
//{
//    class Welcoming
//    {
//        static void Main(string[] args)
//        {
//            Console.Write("Masukkan nama Anda: ");
//            string nama = Console.ReadLine();
//            Console.WriteLine($"Selamat datang, {nama}!");
//        }
//    }
//}

// B Program Print Array dengan Aturan Khusus
//namespace Array
//{
//    class Array
//    {
//        static void Main(string[] args)
//        {
//            // Meminta input dari pengguna untuk menentukan ukuran array
//            Console.Write("Masukkan ukuran array: ");
//            if (!int.TryParse(Console.ReadLine(), out int ukuranArray))
//            {
//                Console.WriteLine("Masukan hanya angka.");
//                return;
//            }

//            // Mencetak Elemen Array dengan Aturan Khusus
//            int[] array = new int[ukuranArray];

//            for (int i = 0; i < array.Length; i++)
//            {
//                array[i] = i;
//            }

//            for (int i = 0; i < array.Length; i++)
//            {
//                if (i % 2 == 0 && i % 3 == 0)
//                {
//                    Console.WriteLine($"{array[i]} #$#$");
//                }
//                else if (i % 2 == 0)
//                {
//                    Console.WriteLine($"{array[i]} ##");
//                }
//                else if (i % 3 == 0)
//                {
//                    Console.WriteLine($"{array[i]} $$");
//                }
//                else
//                {
//                    Console.WriteLine(array[i]);
//                }
//            }
//        }
//    }
//}

// C PrimaAtauBukan
class PrimaAtauBukan
{
    static void Main()
    {
        Console.WriteLine("Masukkan angka antara 1 sampai 10000:");
        string nilaiString = Console.ReadLine();
        int nilaiInt = Convert.ToInt32(nilaiString);

        if (nilaiInt < 1 || nilaiInt > 10000)
        {
            Console.WriteLine("Angka harus antara 1 sampai 10000.");
        }
        else
        {
            if (ApakahBilanganPrima(nilaiInt))
            {
                Console.WriteLine($"Angka {nilaiInt} merupakan bilangan prima");
            }
            else
            {
                Console.WriteLine($"Angka {nilaiInt} bukan merupakan bilangan prima");
            }
        }
    }

    static bool ApakahBilanganPrima(int angka)
    {
        if (angka <= 1) return false;
        if (angka == 2) return true;
        if (angka % 2 == 0) return false;

        for (int i = 3; i <= Math.Sqrt(angka); i += 2)
        {
            if (angka % i == 0) return false;
        }

        return true;
    }
}