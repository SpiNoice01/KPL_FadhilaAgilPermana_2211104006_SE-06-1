﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Testing
{
    [TestClass]
    public class UnitTest1
    {
        Form1 form = new Form1();

        [TestMethod]
        public void TestPangkatBiasa()
        {
            int result = form.CariNilaiPangkat(2, 3); // 2*2*2 = 8
            Assert.AreEqual(8, result);
        }

        [TestMethod]
        public void TestPangkatZero()
        {
            int result = form.CariNilaiPangkat(0, 0); // harus 1
            Assert.AreEqual(1, result);
        }

        [TestMethod]
        public void TestPangkatNegatif()
        {
            int result = form.CariNilaiPangkat(5, -2);
            Assert.AreEqual(-1, result);
        }

        [TestMethod]
        public void TestInputBesar()
        {
            int result = form.CariNilaiPangkat(101, 2);
            Assert.AreEqual(-2, result);
        }

        [TestMethod]
        public void TestOverflow()
        {
            int result = form.CariNilaiPangkat(50000, 3); // 50000^3 = overflow
            Assert.AreEqual(-3, result);
        }
    }

}
