namespace tp12__2211104006
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
            private string CariTandaBilangan(int a)
        {
            if (a < 0)
                return "Negatif";
            else if (a > 0)
                return "Positif";
            else
                return "Nol";
        }


        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Cek_Click(object sender, EventArgs e)
        {
            int angka;
            if (int.TryParse(textBoxInput.Text, out angka))
            {
                labelOutput.Text = CariTandaBilangan(angka);
            }
            else
            {
                labelOutput.Text = "Input tidak valid";
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
