﻿namespace tp12__2211104006
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonCheck = new Button();
            textBoxInput = new TextBox();
            labelOutput = new Label();
            SuspendLayout();
            // 
            // buttonCheck
            // 
            buttonCheck.Location = new Point(138, 121);
            buttonCheck.Name = "buttonCheck";
            buttonCheck.Size = new Size(75, 23);
            buttonCheck.TabIndex = 0;
            buttonCheck.Text = "Cek";
            buttonCheck.UseVisualStyleBackColor = true;
            buttonCheck.Click += Cek_Click;
            // 
            // textBoxInput
            // 
            textBoxInput.Location = new Point(129, 92);
            textBoxInput.Name = "textBoxInput";
            textBoxInput.Size = new Size(100, 23);
            textBoxInput.TabIndex = 1;
            textBoxInput.TextChanged += textBox1_TextChanged;
            // 
            // labelOutput
            // 
            labelOutput.AutoSize = true;
            labelOutput.Location = new Point(235, 95);
            labelOutput.Name = "labelOutput";
            labelOutput.Size = new Size(33, 15);
            labelOutput.TabIndex = 2;
            labelOutput.Text = "Hasil";
            labelOutput.Click += label1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(labelOutput);
            Controls.Add(textBoxInput);
            Controls.Add(buttonCheck);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button buttonCheck;
        private TextBox textBoxInput;
        private Label labelOutput;
    }
}
