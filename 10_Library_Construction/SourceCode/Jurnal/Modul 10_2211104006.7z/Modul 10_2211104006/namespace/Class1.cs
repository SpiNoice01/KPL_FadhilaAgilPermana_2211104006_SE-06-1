﻿using System;

namespace MatematikaLibraries
{
    public class Matematika
    {
        public int FPB(int input1, int input2)
        {
            while (input2 != 0)
            {
                int temp = input2;
                input2 = input1 % input2;
                input1 = temp;
            }
            return input1;
        }

        public int KPK(int input1, int input2)
        {
            return (input1 * input2) / FPB(input1, input2);
        }

        public string Turunan(int[] persamaan)
        {
            string hasil = "";
            int pangkat = persamaan.Length - 1;
            for (int i = 0; i < persamaan.Length - 1; i++)
            {
                int koefisien = persamaan[i] * pangkat;
                if (koefisien == 0)
                {
                    pangkat--;
                    continue;
                }

                string tanda = koefisien > 0 && i > 0 ? " + " : (koefisien < 0 ? " - " : "");
                hasil += (i > 0 ? tanda : (koefisien < 0 ? "-" : "")) +
                         Math.Abs(koefisien) +
                         (pangkat - 1 > 0 ? $"x{pangkat - 1}" : (pangkat - 1 == 0 ? "x" : ""));
                pangkat--;
            }
            return hasil;
        }

        public string Integral(int[] persamaan)
        {
            string hasil = "";
            int pangkat = persamaan.Length - 1;
            for (int i = 0; i < persamaan.Length; i++)
            {
                int newPangkat = pangkat + 1;
                double koefisien = (double)persamaan[i] / newPangkat;

                string tanda = koefisien > 0 && i > 0 ? " + " : (koefisien < 0 ? " - " : "");
                hasil += (i > 0 ? tanda : (koefisien < 0 ? "-" : "")) +
                         (Math.Abs(koefisien) == 1 ? "" : Math.Abs(koefisien).ToString("0.#")) +
                         $"x{newPangkat}";
                pangkat--;
            }
            hasil += " + C";
            return hasil;
        }
    }
}
