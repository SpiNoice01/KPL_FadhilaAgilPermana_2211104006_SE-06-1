﻿using System;
using AljabarLibraries; // penting: pakai namespace!

namespace tpmodul10_console
{
    class Program
    {
        static void Main(string[] args)
        {
            // Contoh menggunakan fungsi HasilKuadrat
            double[] persamaanLinier = { 2, -3 };
            double[] hasilKuadrat = Aljabar.HasilKuadrat(persamaanLinier);

            Console.WriteLine("Hasil Kuadrat dari 2x - 3:");
            Console.WriteLine($"{hasilKuadrat[0]}x^2 {hasilKuadrat[1]}x {hasilKuadrat[2]}");

            // Contoh menggunakan fungsi AkarPersamaanKuadrat
            double[] persamaanKuadrat = { 1, -3, -10 };
            double[] akar = Aljabar.AkarPersamaanKuadrat(persamaanKuadrat);

            Console.WriteLine("\nAkar-akar dari x^2 - 3x - 10:");
            Console.WriteLine($"Akar 1: {akar[0]}");
            Console.WriteLine($"Akar 2: {akar[1]}");

            Console.ReadLine(); // biar konsol nggak langsung nutup
        }
    }
}
