﻿using System;

class Program
{
    static void Main(string[] args)
    {
        BankTransferConfig config = BankTransferConfig.LoadConfig();

        if (config.lang == "en")
        {
            Console.WriteLine("Please insert the amount of money to transfer:");
        }
        else
        {
            Console.WriteLine("Masukkan jumlah uang yang akan di-transfer:");
        }

        long amount = long.Parse(Console.ReadLine());
        long fee = (amount <= config.transfer.threshold) ? config.transfer.low_fee : config.transfer.high_fee;
        long total = amount + fee;

        if (config.lang == "en")
        {
            Console.WriteLine($"Transfer fee = {fee}");
            Console.WriteLine($"Total amount = {total}");
            Console.WriteLine("Select transfer method:");
        }
        else
        {
            Console.WriteLine($"Biaya transfer = {fee}");
            Console.WriteLine($"Total biaya = {total}");
            Console.WriteLine("Pilih metode transfer:");
        }

        for (int i = 0; i < config.methods.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {config.methods[i]}");
        }

        int methodChoice = int.Parse(Console.ReadLine());

        if (config.lang == "en")
        {
            Console.WriteLine($"Please type \"{config.confirmation.en}\" to confirm the transaction:");
        }
        else
        {
            Console.WriteLine($"Ketik \"{config.confirmation.id}\" untuk mengkonfirmasi transaksi:");
        }

        string confirmationInput = Console.ReadLine();

        bool confirmed = (config.lang == "en" && confirmationInput == config.confirmation.en) ||
                         (config.lang == "id" && confirmationInput == config.confirmation.id);

        if (confirmed)
        {
            if (config.lang == "en")
            {
                Console.WriteLine("The transfer is completed");
            }
            else
            {
                Console.WriteLine("Proses transfer berhasil");
            }
        }
        else
        {
            if (config.lang == "en")
            {
                Console.WriteLine("Transfer is cancelled");
            }
            else
            {
                Console.WriteLine("Transfer dibatalkan");
            }
        }
    }
}
