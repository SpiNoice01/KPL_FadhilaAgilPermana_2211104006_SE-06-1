﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using Newtonsoft.Json;

public class BankTransferConfig
{
    public required string lang { get; set; }
    public required Transfer transfer { get; set; }
    public required List<string> methods { get; set; }
    public required Confirmation confirmation { get; set; }

    public class Transfer
    {
        public long threshold { get; set; }
        public long low_fee { get; set; }
        public long high_fee { get; set; }
    }

    public class Confirmation
    {
        public required string en { get; set; }
        public required string id { get; set; }
    }

    private static string configFilePath = "bank_transfer_config.json";

    public static BankTransferConfig LoadConfig()
    {
        if (!File.Exists(configFilePath))
        {
            BankTransferConfig defaultConfig = CreateDefaultConfig();
            SaveConfig(defaultConfig);
            return defaultConfig;
        }
        else
        {
            string json = File.ReadAllText(configFilePath);
            return JsonConvert.DeserializeObject<BankTransferConfig>(json)
                   ?? throw new InvalidOperationException("Failed to deserialize configuration.");
        }
    }

    public static void SaveConfig(BankTransferConfig config)
    {
        string json = Newtonsoft.Json.JsonConvert.SerializeObject(config, Newtonsoft.Json.Formatting.Indented);
        File.WriteAllText(configFilePath, json);
    }

    private static BankTransferConfig CreateDefaultConfig()
    {
        return new BankTransferConfig
        {
            lang = "en",
            transfer = new Transfer
            {
                threshold = 25000000,
                low_fee = 6500,
                high_fee = 15000
            },
            methods = new List<string> { "RTO (real-time)", "SKN", "RTGS", "BI FAST" },
            confirmation = new Confirmation
            {
                en = "yes",
                id = "ya"
            }
        };
    }
}
