﻿using System;
using System.IO;
using Newtonsoft.Json;

class CovidConfig
{
    private string configFile = "covid_config.json";
    public dynamic Config { get; private set; }
    private dynamic defaultConfig = new
    {
        satuan_suhu = "celcius",
        batas_hari_deman = 14,
        pesan_ditolak = "Anda tidak diperbolehkan masuk ke dalam gedung ini",
        pesan_diterima = "Anda dipersilahkan untuk masuk ke dalam gedung ini"
    };

    public CovidConfig()
    {
        LoadConfig();
    }

    private void LoadConfig()
    {
        if (File.Exists(configFile))
        {
            string json = File.ReadAllText(configFile);
            Config = JsonConvert.DeserializeObject(json);
        }
        else
        {
            Config = defaultConfig;
            SaveConfig();
        }
    }

    private void SaveConfig()
    {
        string json = JsonConvert.SerializeObject(Config, Formatting.Indented);
        File.WriteAllText(configFile, json);
    }

    public void UbahSatuan()
    {
        Config.satuan_suhu = Config.satuan_suhu == "celcius" ? "fahrenheit" : "celcius";
        SaveConfig();
    }
}

class Program
{
    static void Main()
    {
        CovidConfig config = new CovidConfig();

        string satuanSuhu = config.Config.satuan_suhu;
        int batasHariDeman = config.Config.batas_hari_deman;
        string pesanDitolak = config.Config.pesan_ditolak;
        string pesanDiterima = config.Config.pesan_diterima;

        Console.Write($"Berapa suhu badan anda saat ini? Dalam nilai {satuanSuhu}: ");
        double suhu = Convert.ToDouble(Console.ReadLine());

        Console.Write("Berapa hari yang lalu (perkiraan) anda terakhir memiliki gejala demam? ");
        int hariDeman = Convert.ToInt32(Console.ReadLine());

        bool kondisiSuhu = satuanSuhu == "celcius" ? (suhu >= 36.5 && suhu <= 37.5) : (suhu >= 97.7 && suhu <= 99.5);

        if (kondisiSuhu && hariDeman < batasHariDeman)
        {
            Console.WriteLine(pesanDiterima);
        }
        else
        {
            Console.WriteLine(pesanDitolak);
        }

        Console.Write("Apakah Anda ingin mengubah satuan suhu? (y/n): ");
        string ubah = Console.ReadLine().ToLower();
        if (ubah == "y")
        {
            config.UbahSatuan();
            Console.WriteLine("Satuan suhu telah diubah menjadi: " + config.Config.satuan_suhu);
        }
    }
}
